export type Aluno = {
    key: number;
    CampoPesquisa: number;
};
