export default class Vertice {
    key: number;
    cp: number;

    constructor(key: number, cp: number) {
        this.key = key;
        this.cp = cp;
    }
}
