export default class Item {
    key: number;
    priority: number;

    constructor(key: number, priority: number) {
        this.key = key;
        this.priority = priority;
    }
}
